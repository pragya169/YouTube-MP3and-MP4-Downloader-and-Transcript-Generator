import os
import tkinter as tk
from tkinter import messagebox, filedialog, ttk
from threading import Thread
from yt_dlp import YoutubeDL
from youtube_transcript_api import YouTubeTranscriptApi, CouldNotRetrieveTranscript
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import re

# Function to validate the YouTube URL
def is_valid_youtube_url(url):
    youtube_regex = (
        r"(https?://)?(www\.)?"
        "(youtube|youtu|youtube-nocookie)\.(com|be)/"
        "(watch\?v=|embed/|v/|.+\?v=)?([^&=%\?]{11})")
    return re.match(youtube_regex, url)

# Extract video ID from URL
def extract_video_id(video_url_or_id):
    from urllib.parse import urlparse, parse_qs
    url_data = urlparse(video_url_or_id)
    if url_data.hostname in ["www.youtube.com", "youtube.com"]:
        return parse_qs(url_data.query).get("v", [None])[0]
    elif url_data.hostname == "youtu.be":
        return url_data.path.lstrip("/")
    return video_url_or_id  # Assume it's already a video ID

# Function to download MP3
def download_mp3(url):
    try:
        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': '%(title)s.%(ext)s',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
        }
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        messagebox.showinfo("Success", "MP3 downloaded successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Error downloading MP3: {e}")
    finally:
        download_button.config(text="Download", state=tk.NORMAL)

# Function to download MP4
def download_mp4(url):
    try:
        ydl_opts = {
            'format': 'best',
            'outtmpl': '%(title)s.%(ext)s',
        }
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        messagebox.showinfo("Success", "MP4 downloaded successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Error downloading MP4: {e}")
    finally:
        download_button.config(text="Download", state=tk.NORMAL)

# Function to fetch transcript and save as PDF
def download_transcript(url):
    try:
        video_id = extract_video_id(url)
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
        transcripts = transcript_list.find_generated_transcript(['en']).fetch()
        save_transcript_as_pdf(transcripts)
    except CouldNotRetrieveTranscript:
        messagebox.showerror("Error", "Transcript could not be retrieved for this video.")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    finally:
        download_button.config(text="Download", state=tk.NORMAL)

# Save transcript as PDF
def save_transcript_as_pdf(transcripts):
    pdf_filename = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
    if not pdf_filename:
        return
    try:
        c = canvas.Canvas(pdf_filename, pagesize=letter)
        width, height = letter
        c.setFont("Helvetica", 12)
        y_position = height - 50
        line_spacing = 14

        for entry in transcripts:
            text = f"[{entry['start']:.2f}s] {entry['text']}"
            if y_position <= 50:
                c.showPage()
                c.setFont("Helvetica", 12)
                y_position = height - 50
            c.drawString(50, y_position, text)
            y_position -= line_spacing

        c.save()
        messagebox.showinfo("Success", f"Transcript saved as {pdf_filename}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Function to start download in a new thread
def start_download(download_type):
    url = url_entry.get()

    # Validate URL
    if not is_valid_youtube_url(url):
        messagebox.showerror("Invalid URL", "Enter a valid YouTube URL.")
        return

    # Change the download button to indicate 'Downloading...'
    download_button.config(text="Downloading...", state=tk.DISABLED)

    if download_type == "MP3":
        Thread(target=download_mp3, args=(url,)).start()
    elif download_type == "MP4":
        Thread(target=download_mp4, args=(url,)).start()
    elif download_type == "Transcript":
        Thread(target=download_transcript, args=(url,)).start()

# GUI Setup
root = tk.Tk()
root.title("YouTube Downloader")
root.geometry("400x500")
root.configure(bg="#f0f0f0")

# Input Field
url_label = tk.Label(root, text="Enter YouTube URL:", font=("Arial", 14), bg="#f0f0f0")
url_label.pack(pady=10)

url_entry = ttk.Entry(root, width=50)
url_entry.pack(pady=10)

# Buttons for Download
button_frame = tk.Frame(root, bg="#f0f0f0")
button_frame.pack(pady=20)

mp3_button = ttk.Button(button_frame, text="Download MP3", command=lambda: start_download("MP3"))
mp3_button.grid(row=0, column=0, padx=10)

mp4_button = ttk.Button(button_frame, text="Download MP4", command=lambda: start_download("MP4"))
mp4_button.grid(row=0, column=1, padx=10)

transcript_button = ttk.Button(root, text="Download Transcript", command=lambda: start_download("Transcript"))
transcript_button.pack(pady=10)

# Download Button
download_button = ttk.Button(root, text="Download", state=tk.DISABLED)
download_button.pack(pady=20)

root.mainloop()
